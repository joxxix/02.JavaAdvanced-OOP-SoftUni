package wildFarm;

import wildFarm.abstractions.Animal;

public class Controler {

    public void makSound(Animal animal){

    }
}
