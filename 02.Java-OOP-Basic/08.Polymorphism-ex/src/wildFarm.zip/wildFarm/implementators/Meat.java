package wildFarm.implementators;

import wildFarm.abstractions.Food;

public class Meat extends Food {

    public Meat(int quantity) {
        super(quantity);
    }
}
