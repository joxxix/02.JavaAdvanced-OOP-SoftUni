package wildFarm.implementators;

import wildFarm.abstractions.Food;

public class Vegetable extends Food {

    public Vegetable(int quantity) {
        super(quantity);
    }
}
