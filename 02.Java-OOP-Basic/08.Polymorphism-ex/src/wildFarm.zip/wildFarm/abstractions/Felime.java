package wildFarm.abstractions;

public abstract class Felime extends Mammal {
    public Felime(String name, String animalType, double animalWeight, int foodEaten) {
        super(name, animalType, animalWeight, foodEaten);
    }
}
