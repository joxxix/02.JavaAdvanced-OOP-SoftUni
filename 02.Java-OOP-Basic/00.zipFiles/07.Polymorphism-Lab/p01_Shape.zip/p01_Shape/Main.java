package p01_Shape;

public class Main {
    public static void main(String[] args) {

    }
}
